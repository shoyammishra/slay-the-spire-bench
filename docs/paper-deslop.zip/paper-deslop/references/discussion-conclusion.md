# Discussion, Limitations, and Conclusion

## Discussion

The discussion is where you argue for the interpretation, which means it is also where overreach lives. Its job is to say what the results mean beyond the specific setting measured, and to be explicit about how far that extrapolation goes.

What belongs here: what the results imply for the field, which competing explanations survive and which do not, how the findings sit against prior work that disagrees, and what the results do not show.

The last of these is the one AI drafts omit. A discussion that only lists implications reads as advocacy. Naming the interpretations your data cannot distinguish between is what makes the rest credible.

Keep the scope limiters. If a finding held on two of three models, the discussion says two of three every time it refers to that finding, not just the first time.

## Limitations

Write these as a researcher describing the boundary of a result, not as a defendant. The tone difference is real and reviewers notice it.

A useful limitation is specific and says what would be needed to remove it: "the address-varying design requires multi-entity binding, which the GPT-2 family fails at every size we tested, so that comparison rests on a single model family. Extending it needs a second architecture that clears the binding floor." That tells a reviewer you understand your own result.

A useless limitation is generic and unfalsifiable: "as with all empirical work, our findings may not generalize to all settings." Every reviewer has read this sentence a thousand times and it registers as evasion.

Do not use the limitations section to smuggle in a strength. "A limitation is that our method is so efficient we could not measure its cost precisely" fools nobody.

Do not apologize. State the boundary and move on.

## Conclusion

Short. Four to six sentences. It restates what was found and what follows, at a higher level than the results section, for a reader who skipped to the end.

What it is not: a summary of the paper's structure ("In Section 3 we introduced... in Section 4 we evaluated..."), a repetition of the abstract, or the place where new results appear for the first time.

Future work, if included, should name a specific next experiment rather than gesturing at directions. "Future work will explore other architectures" is filler. "Whether the dissociation holds under grouped-query attention with fewer key-value heads is the natural next test" is a sentence someone could act on.

## Failure modes across all three

**Conclusions stated more strongly than in the results section.** Claims routinely inflate between Section 5 and Section 7, because the qualifications get dropped on the way. Compare the two directly when both are available, and flag any strengthening.

**The limitation that is never connected to a result.** A limitations section that could be attached to any paper in the subfield is not doing its job.

**Closing on a rhetorical flourish.** "This work opens exciting new avenues for understanding how language models represent knowledge." Cut it. The last sentence of a paper should carry information.

## What you can and cannot fix

You can cut flourishes, remove structural summaries, convert generic limitations into a flag for the author, and restore scope limiters that appear elsewhere in the pasted text. You cannot decide which limitations the work has, and you cannot resolve a discrepancy between a conclusion and a results section you were not given. Flag both as questions.
