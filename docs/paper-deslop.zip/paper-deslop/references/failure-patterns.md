# Deeper AI-Draft Failure Patterns

Load this when a section reads as clean but hollow, when the user says a reviewer flagged the writing as AI-generated, or when the surface edits are done and the text still feels off. These are the failures that survive a punctuation and vocabulary pass, because they are properties of structure and content rather than of wording.

## The paragraph that says nothing

Grammatical, well-connected, and empty. It typically restates the section heading, gestures at the importance of the topic, and moves on. The test: cover the paragraph and ask what the reader now does not know. If the answer is nothing, delete it rather than improving it.

These cluster at the beginning of sections, where a model generates a warm-up paragraph before the content starts.

## Uniform rhythm

Every paragraph four to six sentences, every sentence fifteen to twenty words, every section the same length. Human academic writing is lumpy, because ideas are different sizes. A three-sentence paragraph where the point is small is a sign of a human editor, not a defect.

When you notice uniformity, look for the paragraph that was padded to reach the length and cut it back rather than inflating the others.

## Symmetry that the content does not support

Three bullet points when there were two real ones and a third invented for balance. Two subsections of equal length when one line of prior work matters far more. "First, second, and third" scaffolding on a list that has no natural order. Models produce symmetry because it is a strong prior in the training data, and reviewers read forced symmetry as padding.

## Hedging stacked on hedging

"It may potentially suggest that X could possibly be related to Y." Each hedge is individually defensible; together they say nothing. Pick the one hedge that reflects the real uncertainty and delete the rest. If the uncertainty is genuinely that high, the finding may not belong in the paper.

## Transitions carrying no logical load

"Moreover", "furthermore", "additionally" placed between sentences that have no additive relation. The transition creates an appearance of argument where there is only sequence. Removing them exposes whether the paragraph actually flows; if it does not, the fix is reordering, not more transitions.

## Confident assertions about the literature with no citation

"It is widely believed that", "prior work has generally assumed", "the consensus in the field is". These are claims about other people's work and need support. Models generate them fluently because they are common sentence shapes, and reviewers who work in the area check them.

## The contribution list that is a table of contents

Each bullet describes a section rather than a finding: we introduce a framework, we conduct experiments, we provide analysis. A contribution is something a later paper could cite.

## Numbers that drift

The abstract says 30×, the results say 32×, the discussion says roughly 30×. Each individually plausible, collectively a sign that no one checked. Whenever two numbers in the pasted text refer to the same quantity, compare them explicitly and flag any mismatch, since you may only be seeing one of the places the number appears.

## Terminology that drifts

The same concept called a "cache patch", a "KV intervention", and an "edge intervention" across three paragraphs. Pick the author's dominant term and use it consistently, but flag the choice rather than assuming, because the variants sometimes denote genuinely different things.

## Verification framing

Reviewers respond to a paper that anticipates their objections. The strongest form is to name the alternative explanation before dismissing it, and to name the check that would have falsified your claim. If a section states a result and never mentions what could have gone wrong, that absence is worth flagging even when every sentence is well written.
