# Related Work

Related work exists to answer one reviewer question: why does this paper need to exist given everything already published? Every paragraph should be working toward that answer. A related work section that is only a reading list invites the reviewer to supply the differentiation themselves, and they will usually supply it against you.

## Structure

Two or three thematic subsections, each covering one line of prior work that bears on the paper. Organize by theme, not by chronology and not by venue. Chronological ordering ("Smith et al. proposed X. Then Jones et al. proposed Y.") produces a list, not an argument.

Each subsection has two paragraphs:

**The survey paragraph.** What this line of work does, what it established, what its standard assumptions are. Cite generously here. Group papers that share an approach rather than giving each its own sentence, because one sentence per paper is how a section becomes a list.

**The differentiation paragraph.** What this line of work does not address, and how the present paper relates to it. This is the paragraph that justifies the section's existence. It can say you extend the line, that you contradict a result in it, or that you address a case it excludes by assumption. What it cannot do is stay silent.

## Failure modes specific to related work

**The annotated bibliography.** One sentence per paper, no grouping, no argument. Recognizable by every sentence having the same shape: "Author et al. [n] proposed a method for X."

**Differentiation by dismissal.** "However, these methods are limited." Limited how, and does that limitation matter for the problem at hand? Vague dismissal reads as not having engaged with the work, and if one of those authors is your reviewer it reads worse than that.

**Differentiation that only claims novelty.** "Unlike prior work, we are the first to study Z." Being first is not by itself a contribution, and first-claims are dangerous because a reviewer often knows a counterexample. Prefer describing what you do that the prior line does not enable.

**Missing the closest neighbour.** The paper most similar to yours is the one the reviewer is most likely to know, and omitting it looks either careless or evasive. If the pasted text discusses a field but never names its obvious nearest work, flag it.

**Citations with no anchor to the present paper.** A paragraph of prior work that is never referred to again anywhere in the paper is padding.

## What you can and cannot fix

You can regroup a list into themes when the themes are visible in the text, merge one-sentence-per-paper runs into grouped sentences, and cut dismissive filler. You cannot add citations. If the section is missing a differentiation paragraph, say which subsection lacks it and what question it needs to answer, because only the author knows how their work relates.

Never invent a citation key or a paper title. A hallucinated reference is the single fastest way to get a paper desk-rejected, and it is worse than an incomplete section.
