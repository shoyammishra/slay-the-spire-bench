# Method, Experiments, and Results

These sections work best organized around research questions rather than around the chronology of what you ran. A reviewer is checking whether each claim is supported; structuring by question makes that check easy, and structuring by chronology makes it hard.

## Structure

State the research questions explicitly, then give each one its own subsection. A question like "does patching keys restore the behaviour as effectively as patching values?" is answerable, and its subsection either answers it or reports that it could not be answered.

Within each subsection, the order that reviewers find easiest to verify:

1. **The question,** restated in one sentence.
2. **The setup.** Models, data, hyperparameters, and the metric, at a level of detail sufficient for replication. Anything a reader needs to reproduce the number belongs here or in a named appendix.
3. **The result,** with numbers. Point to the table or figure by name.
4. **The interpretation,** kept separate from the result. The number is a fact; what it means is an argument. Mixing them is how a paper ends up claiming more than it measured.
5. **The control or the confound check.** What else could explain this number, and what you did to rule it out. This paragraph is what separates a paper from a demo, and reviewers look for it specifically.

## Method-section specifics

Define notation before using it and keep it consistent. A symbol that changes meaning between sections is a reliable source of reviewer confusion.

State the assumptions your method requires, including the inconvenient ones. An assumption a reviewer discovers is worth far less than one you declared.

Give the computational cost honestly, in terms of the quantity that scales (context length, number of layers, dataset size), not just wall-clock on your hardware.

Passive voice is more defensible here than elsewhere. "The model was evaluated on 30 pairs" is normal methods prose. Do not mechanically convert every such sentence to active voice; convert the ones where the agent matters.

## Results-section specifics

Every number in the prose must match the corresponding number in the table. This is worth checking character by character, because a mismatch is the kind of error that makes a reviewer doubt everything else.

Report negative and null results in the same voice as positive ones. A result that did not replicate on the third model is a finding, and burying it is both a credibility risk and a wasted contribution.

Distinguish what you measured from what you selected. If a number is a maximum over layers or over seeds, say so, because a max over a sweep is a biased estimator and a reviewer who spots an unlabelled one will assume the bias was deliberate.

Do not narrate the table. "Table 3 shows the results for all models" adds nothing. Say what the table shows: "value patching exceeds key patching by 63× on Mistral-7B (Table 3)."

## Where failed experiments go

Failed and inconclusive experiments belong in the paper, and where they go depends on what they tell the reader.

- An experiment that **tests and fails to support** a claim you make elsewhere goes in the main results, stated plainly. This is the case people most want to hide and most need to report.
- An experiment that **failed for a methodological reason you later fixed** goes in an appendix, with the reason. It saves the next person the same mistake.
- An experiment that **rules out an alternative explanation** is not a failure at all; it is a control, and it belongs in the main text next to the result it defends.
- An experiment that **failed because of a bug or a setup error** goes nowhere. Fix it and rerun, or drop it. Reporting a broken run as a null result is worse than not reporting it.

## What you can and cannot fix

You can reorganize present material into the question-setup-result-interpretation order, separate interpretation that has been fused into a result sentence, and cut table narration. You cannot add a control that was not run, and you cannot reconcile a number in the prose with a number in a table you cannot see. Flag both.
