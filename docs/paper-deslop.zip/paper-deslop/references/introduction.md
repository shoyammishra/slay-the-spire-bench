# Introduction

## The non-expert test applies here too

Like the abstract, the introduction must be readable by someone with beginner-level
exposure to the field rather than by a specialist in your subarea. Define every
technical term the first time it appears, unless it is genuinely common knowledge
for the community you are writing for.

**Use at most two or three numbers in the whole introduction, and state each one
as a comparison rather than as a bare statistic.** "Our method improves over the
strongest prior technique by 12%" gives the reader a scale. "The score is +0.324"
does not, because the reader has not yet met the metric. An introduction carrying
eight or nine raw values reads as a results section and loses the non-specialist
on the first page. Do not list more than two insights or consequences either.

The introduction is the abstract at eight times the length, and it is where most reviewers form their opinion. It runs roughly one page, eight to twelve paragraphs, with one idea per paragraph.

## The eight parts

1. **The broad problem.** Why this area exists. One paragraph, and it can be short. A reviewer in your field does not need to be sold on the field.
2. **What is already known.** The state of the art as it bears on your problem specifically. This is not a related work section; it is the two or three prior results your contribution sits against.
3. **The gap.** What is missing, stated so precisely that the reader could design your experiment themselves. This paragraph does the most work in the whole introduction. If a reviewer cannot articulate the gap after reading it, the paper reads as a solution without a problem.
4. **Your question or hypothesis.** Stated as a question or as a falsifiable claim. Many papers skip this and the introduction goes soft as a result.
5. **Your approach.** How you attacked it, at the level of mechanism. Enough that the reader knows what kind of paper this is before Section 3.
6. **What you found.** The headline results with numbers, usually two or three sentences. Do not defer all results to Section 5; a reviewer who reaches the end of your introduction not knowing what happened is annoyed.
7. **Contributions.** An explicit list, often bulleted. Each item is a thing you did that someone could cite, not a thing you hope is true.
8. **Roadmap.** One short paragraph or none at all. Some venues expect it and some reviewers find it filler. Keep it if the paper has an unusual structure, cut it if the structure is conventional.

## Failure modes specific to introductions

**The funnel that never lands.** Paragraphs 1 and 2 expand to half the page and the gap arrives on the second page. Symptom: you can delete the first two paragraphs and the introduction improves.

**A contribution list that restates the abstract verbatim.** The list should be more specific than the abstract, not a copy of it at the same altitude. If a bullet could be pasted into any paper in the subfield, it is not a contribution.

**Contributions that are activities rather than results.** "We conduct extensive experiments" is something you did with your time, not something a reader gains. "We show that key and value patching dissociate by two orders of magnitude across four models" is a contribution.

**The gap asserted rather than established.** "However, this remains an open problem" with no citation and no argument. A reviewer who works on the problem will know whether it is open, and asserting it without support reads as not having read the literature.

**Results promised but withheld.** "We find surprising results, detailed in Section 5." Say what they are.

**Every paragraph the same length.** A real introduction has a short paragraph where the idea is short. Uniform five-sentence paragraphs across a page is a strong tell of generated text.

## What you can and cannot fix

Reordering, cutting the funnel, converting activity-contributions into result-contributions where the result is stated somewhere in the pasted text, and tightening prose are all safe. Writing the gap paragraph from scratch is not, because the gap is a claim about the literature that only the author can make. If part 3 or part 6 is missing, say so and name what belongs there.
