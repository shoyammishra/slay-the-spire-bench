# Abstract

## The test that outranks the structure

An abstract and an introduction must be readable by a non-expert in your specific
topic. For a machine learning paper that means someone with beginner-level
exposure to ML, not someone working in your exact subarea. Apply this test before
the six-part structure below, because a technically complete abstract that a
non-specialist cannot follow has still failed.

Two consequences follow, and they are the ones most often violated.

**The abstract is not the place to introduce terminology or metrics.** Prefer
metrics a reader already knows, such as accuracy, F1, precision, recall, or
latency. When the paper's central quantity is one the authors defined, naming its
raw values in the abstract tells the reader nothing, because the scale is defined
in Section 3. A reader meeting "ranges from -0.00036 to +0.00103" has no way to
know whether that is large, small, or null. Say what the number means instead:
"near zero on all four models" carries the finding without requiring the scale.

**Ratios and percentages survive this test better than raw scores**, because a
ratio is self-scaling. "Patching values restores 166 times more than patching
keys" is interpretable without knowing what a restoration score is. Prefer that
form when you need a number in the abstract at all.

An abstract is read by three audiences: reviewers deciding whether to bid on the paper, an area chair skimming twenty of them, and researchers deciding whether to read further. All three want the same six things, in this order. Six to eight sentences total, roughly 150 to 250 words.

## The six parts

1. **Context.** What area this sits in and why anyone works on it. One sentence. Not a history of the field.
2. **Gap.** What is not known or not working. This is the sentence the rest of the paper exists to fill, so it has to be specific enough that the contribution is obviously responsive to it. "Little is known about X" is weak; "existing methods for X assume Y, which fails when Z" is the shape you want.
3. **What you did.** The method or the experiment, named concretely. A reader should be able to tell one method from another after this sentence.
4. **The headline result,** with numbers. An abstract without a number is a promise. Give the effect size, the accuracy, the ratio, whatever the paper's main quantity is.
5. **Why it matters.** What changes for someone else because of this result. One sentence, and resist inflating it.
6. **Scope or limitation.** One clause. This costs nothing and buys credibility, because the reviewer who spots the limitation themselves will assume you did not.

The order is not sacred but the coverage is. Parts 2 and 4 are the ones most often missing from AI drafts.

## Failure modes specific to abstracts

**No number in the result sentence.** The most common defect. "We show substantial improvements" tells a reviewer nothing and reads as hiding something.

**Context that eats the word budget.** Three sentences of background before the gap appears. The reader knows the field; that is why they are reading the abstract.

**Gap and contribution that do not match.** The gap says one thing is missing, the contribution delivers something adjacent. Check these two sentences against each other directly, because they are usually written at different times.

**Method described by its properties rather than its mechanism.** "We propose a novel, efficient framework" describes how the authors feel about the method. Say what it does.

**A closing sentence that restates the opening.** Abstracts do not need conclusions.

**Future tense about the paper's own content.** "We will show" belongs in a proposal. Use present tense for what the paper does and past tense for what the experiments found.

## What you can and cannot fix

You can reorder sentences that are present but out of sequence, cut the background down, and strip inflation. You cannot invent the number for part 4 or the limitation for part 6. When those are missing, say which part is missing and what it needs, and leave a clearly marked gap rather than a plausible-sounding invention.
