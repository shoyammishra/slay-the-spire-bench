---
name: paper-deslop
description: Rewrite a section of an academic paper to remove AI-generated writing tells while keeping the author's meaning and evidence exact. Strips em dashes, en dashes, connector semicolons, and the LLM vocabulary tics (delve, leverage, robust, moreover, furthermore, notably, comprehensive, it is important to note, plays a crucial role), splits bloated sentences, converts passive to active, and checks the section against the structural template reviewers expect for that section type. Use this whenever the user pastes a chunk of a paper — an abstract, introduction, related work, method, results, discussion, conclusion, or even a single paragraph — and asks to refactor, de-slop, tighten, clean up, remove AI-isms, make it sound human, or get it submission-ready for a venue like TMLR, NeurIPS, ICML, ICLR, ACL, or a journal. Also use it when the user says their writing "sounds like ChatGPT" or a reviewer flagged the prose as AI-generated. Applies to LaTeX source and plain prose alike.
---

# Paper De-Slop

Rewrite academic prose so it reads as though a careful researcher wrote it, not a language model. The author's claims, numbers, citations, and hedges are theirs and stay exactly as given. Only the writing changes.

## How this skill is normally used

The user pastes **one section at a time**, not the whole paper. Treat every invocation as a self-contained job on the text in front of you. Do not ask for the rest of the paper, do not ask for context you can infer, and do not refuse to edit because you cannot see the surrounding sections. If a structural rule depends on something outside the pasted text (whether a figure exists, whether a claim is supported by a later experiment), flag it as a question for the author rather than treating it as a blocker.

## The one rule that outranks the rest

**Never alter a factual claim to make a sentence read better.** Numbers, model names, dataset sizes, citation anchors, statistical qualifiers, and scope limiters ("on two of three models", "in the content-varying design") are load-bearing. A reviewer who finds a number that disagrees with a table stops trusting the paper. If a sentence is awkward *because* it is carrying a precise qualification, keep the qualification and fix the grammar around it.

Corollary: if you cannot rewrite something without guessing at what the author meant, leave the original line in place and note it under "Questions for you" at the end.

## Workflow

1. **Identify the section.** Read the pasted text and decide what it is: abstract, introduction, related work, method, results, discussion, limitations, conclusion, or a fragment that belongs to one of these. The section type determines which structural template applies. If genuinely ambiguous, state your assumption in one line and proceed — do not stall on it.
2. **Apply the universal rules** below. These hold for every section.
3. **Load the structural guidance** for that section type from `references/` and check the text against it. Only load the file you need.
4. **Return the rewritten text**, then a short change report.

## Universal rules

These are the ones that do the most work. Read the reasoning, not just the prohibition, because the reasoning tells you when a rule bends.

### Punctuation that marks a text as machine-written

Em dashes and en dashes used as prose connectors are the single strongest tell. So are semicolons joining two independent clauses, and colons introducing a continuation of a sentence rather than a list or a definition. Human academics use these, but sparsely and unevenly; language models use them constantly and rhythmically, and that regularity is what gets noticed.

Remove all of them from prose. The replacement depends on what the dash was doing:

- Joining two related independent clauses → make two sentences, or join with a conjunction that names the relation ("because", "so", "but", "which means").
- Wrapping a parenthetical aside → use commas, or parentheses, or cut the aside if it was filler.
- Introducing an explanation or elaboration → start a new sentence.

What survives: hyphens in compound modifiers (`content-varying design`, `layer-wise`), en dashes in numeric ranges (`layers 12–18`) and LaTeX math, and colons introducing a genuine list or a definition. Those are typography, not connectors.

In LaTeX source this means `---`, `--` between words, and `;` between clauses. Leave `--` inside numeric ranges and anything inside `$...$`, `\cite{}`, `\ref{}`, or verbatim blocks untouched.

### Vocabulary that flags the text

These words and phrases are overrepresented in model output to the point of being diagnostic. Remove them:

delve, straightforward, it's worth noting, it is important to note, importantly, notably, in the realm of, leverage, robust, nuanced, certainly, of course, absolutely, comprehensive, facilitate, utilize, ensure, moreover, furthermore, in conclusion, to summarize, plays a crucial role, serves as a foundation.

Most of them want deleting rather than replacing. "Importantly", "notably", and "it is worth noting" are almost always announcing importance the sentence should demonstrate on its own; cut the word and the sentence is stronger. "Moreover" and "furthermore" are usually padding between two sentences that already follow each other; cut and the paragraph tightens. "Leverage" means "use". "Utilize" means "use". "Facilitate" means "let" or "help". "Ensure" means "guarantee" or "make sure" and often the honest version is weaker, which is the point.

Two of these need care. **Robust** is a real technical term in statistics and optimization (a robust estimator, robustness to distribution shift). Keep it where it carries that meaning and cut it where it means "good". **Comprehensive** is banned as self-praise about your own work but is fine when describing a cited survey.

Rewriting a banned word into an equally inflated synonym defeats the purpose. "Leverage" → "harness" is not progress.

### The non-expert test, for abstracts and introductions

An abstract and an introduction have to be readable by someone with beginner-level
exposure to the field, not by a specialist in the paper's subarea. This is a
different test from "does this sound like a machine wrote it", and a section can
pass the style rules while failing this one badly.

What it rules out: raw values of a metric the paper itself defines, acronyms used
before they are expanded, and more than two or three numbers in total. A reader
who meets "+0.324" before reaching the section that defines the scale learns
nothing from it. Convert such numbers to interpretable statements ("near zero on
all four models") or to ratios, which are self-scaling. Define every technical
term at first use.

### Sentence construction

Write full sentences. Fragments, arrow notation, and telegraphic bullet-speak read as notes, not as a paper.

Prefer active voice with a real subject. "We patch the cache at layer 14" beats "the cache is patched at layer 14". Passive is correct when the agent is irrelevant or unknown ("the models were released in 2024"), and Methods sections legitimately use more of it than other sections, so do not purge it mechanically.

Split sentences past roughly twenty-five words. This is a heuristic, not a hard limit. A long sentence that carries one clean idea with parallel structure is fine. A long sentence that has accumulated three clauses because each one was hedging the last is the actual target. When you split, check that the second sentence still has a subject the reader can find.

Avoid the defensive "X, not Y" construction where Y was never on the table. This
includes every form it takes: "rather than", "instead of", "not merely", "as
opposed to", and bare "not X but Y". These accumulate invisibly, because each one
looks defensible in isolation. Count them across a finished section: more than
two or three in a page is a rhythm a reader notices even when no single instance
is wrong, and it is one of the most reliable signals that a draft was machine
written. When you find a cluster, keep the one where the contrast carries the
argument and rewrite the rest as direct statements. "We measure the restoration score, not the raw probability" only earns its place if a reader would plausibly have assumed the raw probability. Otherwise it is the prose equivalent of flinching, and models produce it constantly. Contrast is good when the contrast is real.

### Claims

Claim exactly what the evidence supports. Weaken "demonstrates" to "suggests" or "is consistent with" when the result is one experiment on one model. Keep every scope limiter the author wrote. If the pasted text makes a claim broader than the numbers in the same paragraph, flag it rather than silently narrowing it, because you may be missing evidence from a section you cannot see.

Every figure, table, and appendix mentioned in prose needs a reference the reader can follow (`Figure 3`, `Table 2`, `Appendix B`). If the text says "as shown in the figure below", it needs a real anchor. Flag missing ones.

### Paragraph shape

One paragraph carries one point, stated in the first sentence. Models tend to write paragraphs that begin with a scene-setting sentence and bury the claim in the middle. When you find one, move the claim to the front.

Cut sentences that restate the previous sentence with different words. This is the most common form of AI bloat and it is invisible until you look for it specifically. After rewriting, reread each paragraph and ask which sentence you could delete without losing information.

Do not end a section by summarizing what the section just said. Reviewers read the section.

## Section-specific structure

After the universal pass, load the file matching the section and check the structure:

| Section | Reference file |
|---|---|
| Abstract | `references/abstract.md` |
| Introduction | `references/introduction.md` |
| Related Work | `references/related-work.md` |
| Method, Experiments, Results | `references/method-results.md` |
| Discussion, Limitations, Conclusion | `references/discussion-conclusion.md` |

Structural problems are reported, not silently fixed. If an abstract is missing its result sentence, you cannot invent the result. Say what is missing and where it goes. If the fix is genuinely mechanical (reordering two sentences that are already present), do it and say you did.

`references/failure-patterns.md` catalogues the deeper AI-draft failures that survive a surface edit: the paragraph that says nothing, the uniform paragraph lengths, the contribution list that repeats the abstract. Load it when the text reads as clean but hollow, or when the user says a reviewer called the writing AI-generated.

## Output format

Return this, in this order:

1. **The rewritten section**, complete and ready to paste back. Match the input format: LaTeX in, LaTeX out, with the author's macros, `\cite{}` keys, labels, and environments preserved exactly. Do not add markdown formatting to LaTeX source.
2. **What changed** — a compact list of the substantive edits, grouped by kind rather than by line. "Removed 7 em dashes, 3 as sentence splits and 4 as comma-bounded asides" is more useful than seven separate entries. Name the banned words you removed. Note any sentence you split for length.
3. **Structural notes** — where the section deviates from the template for its type, and what is missing.
4. **Questions for you** — anything you could not resolve without the author: an ambiguous referent, a claim you suspect overreaches, a missing figure anchor, a number that looks inconsistent with a neighbouring number.

Keep sections 2 through 4 tight. The author wants the text back, with enough of a report to check your work and to learn the pattern. A change report longer than the section defeats the purpose.

If a passage is already clean, say so rather than manufacturing edits to look useful. Churning good prose is a real cost, because the author then has to re-verify lines that were already correct.

## Verification before you return

The author is submitting this to a venue where a punctuation slip is a real embarrassment, so check your own output rather than trusting that you followed your own instructions:

- Grep your rewritten text for `—`, `–`, and `;`. Every remaining instance should be a numeric range, math, or a genuine list separator. This catches the case where you removed six em dashes and introduced a seventh.
- Grep for the banned words. Models reintroduce them while rewriting a neighbouring sentence.
- Reread the numbers and citation keys against the input. They should be character-identical.

`scripts/check.py` does all three checks at once. Write your rewritten text to a file and run it:

```bash
python3 scripts/check.py rewritten.tex
```

It reports punctuation tells, banned words, sentences over 25 words, and figure or table mentions with no numbered anchor. It knows to skip math, `\cite{}` keys, and numeric ranges like `12--18`, so a finding is worth looking at rather than noise.

### Hedge pile-ups

`hedge-pileup` fires when the same caveat appears three times inside four
sentences. A paper states a limitation once; a draft revised several times
states it three ways in a paragraph, and that reads as the paper worrying rather
than reporting. Each sentence looks careful in isolation, which is why the
pile-up survives every pass until someone counts.

The check works on semantic frames, not words, because the repetitions are
paraphrases. "We establish this on gpt2-medium alone", "it is not replicated
across models", and "this accuracy comparison covers one" share almost no
vocabulary and make one claim. Word-level matching finds nothing there.

When it fires, keep the clearest statement and cut the rest. Then check the
Limitations section, because that is usually where the same caveat appears a
fourth time in slightly different words.

### What the script still cannot see

**A sentence that restates its predecessor.** The hedge check only covers
caveats. General restatement needs semantic comparison the script cannot do, so
read each paragraph and ask which sentence you could delete without losing
information. This is the most common form of AI bloat and it is invisible until
you look for it on purpose.

A clean script run means the lexical tells are gone, not that the prose is
finished.

Its output is advisory, not a set of required edits. It flags "robust" and "comprehensive" separately under `banned-word-check-context` precisely because those have legitimate technical uses, and a long sentence carrying one clean parallel idea can stay long. Use it to catch what you missed, then decide.
