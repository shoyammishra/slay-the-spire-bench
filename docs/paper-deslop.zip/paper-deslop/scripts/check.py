#!/usr/bin/env python3
"""Flag AI-writing tells in a section of a paper.

Run this on the rewritten text before returning it. Grepping is more reliable
than rereading, because the failure mode is removing six em dashes and
introducing a seventh while rewriting a neighbouring sentence.

    python check.py section.tex
    pbpaste | python check.py -

Exit status is 1 when anything is flagged, so it composes in a pipeline.
Findings are advisory: a flagged line is a line to look at, not automatically
a line to change. "Robust" in the statistical sense and a colon before a real
list are both correct and both get flagged.
"""

import re
import sys

BANNED = [
    "delve", "delves", "delving", "straightforward", "it's worth noting",
    "it is worth noting", "it is important to note", "importantly", "notably",
    "in the realm of", "leverage", "leverages", "leveraging", "robust",
    "robustly", "nuanced", "certainly", "of course", "absolutely",
    "comprehensive", "facilitate", "facilitates", "facilitating", "utilize",
    "utilizes", "utilizing", "ensure", "ensures", "ensuring", "moreover",
    "furthermore", "in conclusion", "to summarize", "plays a crucial role",
    "serves as a foundation",
]

# Words whose technical use is legitimate; reported separately so the author
# can wave them through rather than being told to purge a real term of art.
CONTEXT_DEPENDENT = {"robust", "robustly", "comprehensive", "ensure",
                     "ensures", "ensuring"}

LONG_SENTENCE = 25


def strip_protected(line):
    """Blank out regions where dashes and semicolons are typography, not prose.

    Math, citation keys, refs, and URLs legitimately contain the characters we
    are hunting, so scanning them produces noise that trains the reader to
    ignore the report.
    """
    line = re.sub(r"\$[^$]*\$", lambda m: " " * len(m.group()), line)
    line = re.sub(r"\\(cite|ref|label|eqref|citep|citet|autoref)\{[^}]*\}",
                  lambda m: " " * len(m.group()), line)
    line = re.sub(r"https?://\S+", lambda m: " " * len(m.group()), line)
    return line


# Hedge frames. Each is a way of saying "this result is narrower than it looks".
# A paper states a given caveat once; a draft that has been revised several times
# states it three or four ways in the same paragraph, which reads as the paper
# worrying rather than reporting. The repetitions rarely share vocabulary, so
# word-level matching misses them -- what they share is the frame.
_HEDGE_FRAMES = {
    "narrow scope": r"\b(?:on\s+\S+\s+alone|only\s+(?:one|a\s+single)|"
                    r"a\s+single\s+model|covers?\s+(?:just\s+)?one|"
                    r"not\s+replicated|is\s+untested|remains\s+untested|"
                    r"we\s+did\s+not\s+(?:test|evaluate)|cannot\s+establish)\b",
    "weak evidence": r"\b(?:do(?:es)?\s+not\s+(?:claim|establish|show|prove)|"
                     r"no\s+formal\s+\S+\s+test|not\s+(?:a\s+)?"
                     r"(?:statistical|causal)\s+null|should\s+not\s+be\s+"
                     r"(?:read|interpreted|compared)|is\s+not\s+itself)\b",
    "not an artefact": r"\b(?:not\s+an?\s+artefact|not\s+an?\s+artifact|"
                       r"is\s+not\s+explained\s+by|cannot\s+be\s+explained|"
                       r"does\s+not\s+account\s+for|rules?\s+out)\b",
}


def _hedge_pileup(text, window=4, threshold=3):
    """Flag a caveat restated several times inside a few sentences.

    Not a claim that any one sentence is wrong. Each is usually defensible; the
    problem is the count. Three statements of the same limitation in four
    sentences is the single clearest signal a reviewer reads as defensiveness,
    and it is invisible while writing because each addition felt careful.

    Checked per frame rather than per word, because the repetitions are
    paraphrases: "established on gpt2-medium alone", "not replicated across
    models", and "this comparison covers one" share almost no vocabulary and
    make an identical claim.
    """
    body = re.sub(r"\\begin\{(table|figure|tabular|equation)\}.*?\\end\{\1\}",
                  " ", text, flags=re.S)
    body = re.sub(r"(?m)^\s*%.*$", " ", body)
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", body) if s.strip()]

    out = []
    for name, pat in _HEDGE_FRAMES.items():
        hits = [i for i, s in enumerate(sents) if re.search(pat, s, re.I)]
        for k in range(len(hits)):
            group = [i for i in hits[k:] if i - hits[k] < window]
            if len(group) >= threshold:
                out.append((None, "hedge-pileup",
                            f'"{name}" stated {len(group)} times within '
                            f"{window} sentences",
                            " ".join(sents[group[0]].split())[:110] + "..."))
                break
    return out


def check(text):
    findings = []
    lines = text.split("\n")

    for i, raw in enumerate(lines, 1):
        line = strip_protected(raw)
        low = line.lower()

        for ch, name in (("\u2014", "em dash"), ("\u2013", "en dash")):
            if ch in line:
                findings.append((i, "punctuation", f"{name} in prose", raw.strip()))
        # LaTeX source dashes. "--" between digits is a numeric range and fine.
        if "---" in line:
            findings.append((i, "punctuation", "LaTeX em dash (---)", raw.strip()))
        for m in re.finditer(r"(?<!-)--(?!-)", line):
            a, b = line[max(0, m.start() - 1):m.start()], line[m.end():m.end() + 1]
            # A range (12--18) and a closed compound (key--value) are both
            # typography. Only a dash with whitespace around it, or one joining
            # clauses, is the prose connector we are hunting.
            spaced = a in (" ", "") or b in (" ", "")
            if not (a.isdigit() and b.isdigit()) and spaced:
                findings.append((i, "punctuation", "LaTeX en dash (--) in prose",
                                 raw.strip()))
        if ";" in line:
            findings.append((i, "punctuation",
                             "semicolon (fine in a list, not as a clause connector)",
                             raw.strip()))

        for w in BANNED:
            if re.search(r"\b" + re.escape(w) + r"\b", low):
                kind = "banned-word-check-context" if w in CONTEXT_DEPENDENT else "banned-word"
                findings.append((i, kind, f'"{w}"', raw.strip()))

    # Defensive-contrast constructions. Individually defensible, collectively a
    # rhythm reviewers read as machine-written, so they are counted not listed.
    contrast = re.findall(r"\b(rather than|instead of|not merely|as opposed to)\b",
                          text, re.I)
    if len(contrast) > 3:
        findings.append((None, "defensive-contrast",
                         f"{len(contrast)} instances of rather than/instead of/"
                         f"not merely across this text", ""))

    findings += _hedge_pileup(text)

    prose = strip_protected(text)
    prose = re.sub(r"\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^}]*\})?", " ", prose)
    for sent in re.split(r"(?<=[.!?])\s+", prose):
        n = len(sent.split())
        if n > LONG_SENTENCE:
            findings.append((None, "long-sentence", f"{n} words",
                             " ".join(sent.split())[:110] + "..."))

    if not re.search(r"\b(Figure|Fig\.|Table|Appendix)\s*~?\\?ref|"
                     r"\b(Figure|Fig\.|Table|Appendix)\s+\d|\\ref\{", text):
        if re.search(r"\b(figure|table|appendix)\b", text, re.I):
            findings.append((None, "reference",
                             "mentions a figure/table/appendix with no numbered anchor",
                             ""))
    return findings


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "-"
    text = sys.stdin.read() if src == "-" else open(src, encoding="utf-8").read()

    findings = check(text)
    if not findings:
        print("clean: no punctuation tells, banned words, or long sentences found")
        return 0

    order = ["punctuation", "banned-word", "banned-word-check-context",
             "defensive-contrast", "hedge-pileup", "long-sentence", "reference"]
    for kind in order:
        group = [f for f in findings if f[1] == kind]
        if not group:
            continue
        print(f"\n{kind}  ({len(group)})")
        for ln, _, what, ctx in group:
            loc = f"  line {ln}: " if ln else "  "
            print(f"{loc}{what}")
            if ctx:
                print(f"      {ctx[:150]}")
    print(f"\n{len(findings)} findings. Each is a line to look at, not "
          f"automatically a line to change.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
